<?php
/**
 * Plugin Name: WP Contact Form
 * Plugin URI: https://www.wpwebelite.com/
 * Description: This plugin use for submit contact form data and display as custom post type in admin side. 
 * Version: 1.0.0
 * Author: WPWeb
 * Author URI: https://www.wpwebelite.com/
 * Text Domain: wpcp
 * Domain Path: languages
 * 
 * @package WP CONTACT FORM
 * @category Core
 * @author WPWeb
 */

/**
 * Define Some needed predefined variables
 * 
 * @package WP CONTACT FORM
 * @since 1.0.0
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Basic Plugin Definitions 
 * 
 * @package WP CONTACT FORM
 * @since 1.0.0
 */
if( !defined( 'WPCF_VERSION' ) ) {
	define( 'WPCF_VERSION', '1.0.0' ); //version of plugin
}
if( !defined( 'WPCF_DIR' ) ) {
	define( 'WPCF_DIR', dirname( __FILE__ ) ); // plugin dir
}
if( !defined( 'WPCF_ADMIN' ) ) {
	define( 'WPCF_ADMIN', WPCF_DIR . '/includes/admin' ); // plugin admin dir
}
if(!defined('wpcflevel')) { //check if variable is not defined previous then define it
	define('wpcflevel','manage_options'); // this is capability in plugin
}
if(!defined('WPCF_URL')) {
	define('WPCF_URL',plugin_dir_url( __FILE__ ) ); // plugin url
}
if(!defined('WPCF_POST_TYPE')) {
	define('WPCF_POST_TYPE', 'wpcf');
}
//metabox prefix
if( !defined( 'WPCF_META_PREFIX' )) {
	define( 'WPCF_META_PREFIX', '_wpcf_' );
}
if( !defined( 'WPCF_PLUGIN_BASENAME' ) ) {
	define( 'WPCF_PLUGIN_BASENAME', basename( WPCF_DIR ) ); //Plugin base name
}

/**
 * Load Text Domain
 * 
 * This gets the plugin ready for translation.
 * 
 * @package WP CONTACT FORM
 * @since 1.0.0
 */
function wpcf_load_textdomain() {
	
	// Set filter for plugin's languages directory
	$wpcf_lang_dir	= dirname( plugin_basename( __FILE__ ) ) . '/languages/';
	$wpcf_lang_dir	= apply_filters( 'wpcf_languages_directory', $wpcf_lang_dir );
	
	// Traditional WordPress plugin locale filter
	$locale	= apply_filters( 'plugin_locale',  get_locale(), 'wpcf' );
	$mofile	= sprintf( '%1$s-%2$s.mo', 'wpcf', $locale );
	
	// Setup paths to current locale file
	$mofile_local	= $wpcf_lang_dir . $mofile;
	$mofile_global	= WP_LANG_DIR . '/' . WPCF_PLUGIN_BASENAME . '/' . $mofile;
	
	if ( file_exists( $mofile_global ) ) { // Look in global /wp-content/languages/wp-front-post folder
		load_textdomain( 'wpcf', $mofile_global );
	} elseif ( file_exists( $mofile_local ) ) { // Look in local /wp-content/plugins/wp-front-post/languages/ folder
		load_textdomain( 'wpcf', $mofile_local );
	} else { // Load the default language files
		load_plugin_textdomain( 'wpcf', false, $wpcf_lang_dir );
	}
	 
}

/**
 * Plugin Activation hook
 * 
 * This hook will call when plugin will activate
 * 
 * @package WP CONTACT FORM
 * @since 1.0.0
 */
register_activation_hook( __FILE__, 'wpcf_install' );

function wpcf_install() {
	
	global $wpdb;
}


/**
 * Plugin Deactivation hook
 * 
 * This hook will call when plugin will deactivate
 * 
 * @package WP CONTACT FORM
 * @since 1.0.0
 */
register_deactivation_hook( __FILE__, 'wpcf_uninstall' );

function wpcf_uninstall() {
	
	global $wpdb;	
}

// Allow non-authenticated users to upload files
add_filter('wp_handle_upload_prefilter', 'allow_non_authenticated_uploads');

function allow_non_authenticated_uploads($file) {
    $file['error'] = '';

    // Check if the user is logged in
    if (!is_user_logged_in()) {
        // Allow uploads for non-authenticated users
        remove_filter('wp_handle_upload_prefilter', 'allow_non_authenticated_uploads');
    }

    return $file;
}

/**
 * Includes Class Files
 * 
 * @package WP CONTACT FORM
 * @since 1.0.0
 */
global $wpcf_model,$wpcf_scripts,$wpcf_admin, $errors, $errmsg;

require_once(WPCF_ADMIN . '/class-wpcf-custom-post-type.php');
require_once(WPCF_ADMIN . '/class-wpcf-shortcode.php');
require_once(WPCF_ADMIN . '/class-wpcf-scripts.php');










