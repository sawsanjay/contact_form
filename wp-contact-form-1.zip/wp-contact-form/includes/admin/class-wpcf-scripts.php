<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Scripts Class
 *
 * Handles adding scripts and styles functionality to the admin and frontend pages.
 *
 * @package WP Front Post
 * @since 1.0.0
 */
class WPCF_Scripts {

    public function __construct() {
      //add_action('admin_enqueue_scripts', array($this, 'wpcf_admin_enqueue_styles_and_scripts'));
      
        add_action('wp_enqueue_scripts', array($this, 'wpcf_frontend_enqueue_styles_and_scripts'));
    }

  

    /**
     * Enqueue Styles and Scripts for the Admin
     *
     * @package WP Front Post
     * @since 1.0.0
     */
    public function wpcf_admin_enqueue_styles_and_scripts() {
        wp_register_style('wpcf-admin');
        wp_enqueue_style('wpcf-admin');
        wp_enqueue_script('wpcf-admin-script');
    }

    /**
     * Enqueue Styles and Scripts for the Frontend
     *
     * @package WP Front Post
     * @since 1.0.0
     */
    public function wpcf_frontend_enqueue_styles_and_scripts() {

        wp_enqueue_script('jquery');

        //wp_enqueue_script('jquery-validation', WPCF_URL . 'includes/js/jquery.validate.min.js', array('jquery'), WPCF_VERSION, true);
        //wp_enqueue_script('wpcf-form-validation-script', WPCF_URL . 'includes/js/wpcf-form-validation-script.js', array('jquery', 'jquery-validation'), WPCF_VERSION, true);
    
        
        wp_enqueue_script('wpcf-form-media-box', WPCF_URL . 'includes/js/wpcf-media.js', array('jquery'), WPCF_VERSION, true);
        wp_enqueue_script('wpcf-form-ajax-script', WPCF_URL . 'includes/js/wpcf-script.js', array('jquery'), WPCF_VERSION, true);
        wp_localize_script('wpcf-form-ajax-script', 'wpcf_vars', array(
            'ajaxurl' => admin_url('admin-ajax.php'),

        ));

        wp_register_style('wpcf-frontend', WPCF_URL . 'includes/css/wpcf-style.css', array(), WPCF_VERSION);
        wp_enqueue_style('wpcf-frontend');
        wp_enqueue_media();

  
    }
}
$wpcf_scripts = new WPCF_Scripts();
