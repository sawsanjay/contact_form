<?php
/// Exit if accessed directly
if (!defined('ABSPATH')) exit;

class WPCF_Shortcode {
    public $errmsg = array();

    public function __construct() {
        // Add shortcode
        add_shortcode('wpcf_form', array($this, 'wpcf_render_form_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'wpcf_enqueue_scripts'));
        
        // Add AJAX action for handling form submission
        add_action('wp_ajax_wpcf_handle_form_submission', array($this, 'wpcf_handle_form_submission'));
        add_action('wp_ajax_nopriv_wpcf_handle_form_submission', array($this, 'wpcf_handle_form_submission'));
    }
   
     /**
     * Enqueue necessary scripts for media uploader
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_enqueue_scripts() {
        if (!did_action('wp_enqueue_media')) {
            wp_enqueue_media();
        }
    }

    /**
     * Render the form shortcode
     *
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_render_form_shortcode() {
        // You can output your form HTML here
        ob_start();
        ?>
        <form method="post" enctype="multipart/form-data" id="wpcf-form">
        <input type="hidden" id="_wpnonce" name="_wpnonce" value="400b4392d3">
            <label for="post_title"><?php echo esc_html__( 'Name', 'wpcf' ) ?><span style="color:red;">*</span></label>
            <input type="text" name="post_title" id="post_title" placeholder="Your Name" >
            <?php
            if(isset($this->errmsg['post_title']) && !empty($this->errmsg['post_title'])) { 
                echo '<div style="color:red;">'.$this->errmsg['post_title'].'</div>';
            }
            ?>	

            <label for="post_email"><?php echo esc_html__( 'Email', 'wpcf' ) ?><span style="color:red;">*</span></label>
            <input type="text" name="post_email" id="post_email" placeholder="Your Email">
            <div id="email_message"></div>
            <?php
            if(isset($this->errmsg['post_email']) && !empty($this->errmsg['post_email'])) { 
                echo '<div style="color:red;">'.$this->errmsg['post_email'].'</div>';
            }
            ?>

            <label for="post_phone"><?php echo esc_html__( 'Phone Number', 'wpcf' ) ?><span style="color:red;">*</span></label>
            <input type="text" name="post_phone" id="post_phone" placeholder="Your Phone Number">
            <div id="phone_message"></div>
            <?php
            if(isset($this->errmsg['post_phone']) && !empty($this->errmsg['post_phone'])) { 
                echo '<div style="color:red;">'.$this->errmsg['post_phone'].'</div>';
            }
            ?>

            <!-- <label for="post_image"><?php //echo esc_html__( 'Choose Image', 'wpcf' ) ?><span style="color:red;">*</span></label>
            <input type="file" name="post_image" id="post_image" accept="image/jpeg,image/png" >
            <?php
            // if(isset($this->errmsg['post_image']) && !empty($this->errmsg['post_image'])) { 
            //     echo '<div style="color:red;">'.$this->errmsg['post_image'].'</div>';
            // }
            ?>  -->
            <!-- <label for="post_image"><?php //echo esc_html__( 'Choose Image', 'wpcf' ) ?><span style="color:red;">*</span></label>                                                                      
            <input type="hidden" name="post_image" id="post_image" class="image-url">
            <button type="button" class="button button-primary" id="upload_image_button"><?php echo esc_html__( 'Upload Image', 'wpcf' ) ?></button>

            <?php
            // if(isset($this->errmsg['post_image']) && !empty($this->errmsg['post_image'])) { 
            //     echo '<div style="color:red;">'.$this->errmsg['post_image'].'</div>';
            // }
            ?> -->
            <label for="post_image"><?php echo esc_html__( 'Choose Image', 'wpcf' ) ?><span style="color:red;">*</span></label>
            <input type="hidden" name="post_image" id="post_image" class="image-url" value="">
            <button type="button" class="button button-primary" id="upload_image_button"><?php echo esc_html__( 'Upload Image', 'wpcf' ) ?></button>
            <div>
                <img src="http://sanjay.wpweb.co.in/wordpress2/wp-content/uploads/2023/12/images.png" id="selected_image_preview" alt="Selected Image" style="width: 200px; height: 150px;">
            </div>
            <?php
            if(isset($this->errmsg['post_image']) && !empty($this->errmsg['post_image'])) { 
                echo '<div style="color:red;">'.$this->errmsg['post_image'].'</div>';
            }
            ?>
            
            <small><?php echo esc_html__( 'Note: Only JPEG and PNG formats are allowed. Maximum file size is 2MB.', 'wpcf' ) ?></small>
            <input type="submit" value="SUBMIT" id="submit-btn">  
            <div id="message"></div>
        </form>
        <?php
        return ob_get_clean();
    }

     /**
     * upload image from front
     *
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_handle_form_submission() {
        $response = array();
        $email = sanitize_text_field($_POST['post_email']);
        $phone = sanitize_text_field($_POST['post_phone']);

        $email_exists = $this->is_email_exists($email);
        $phone_exists = $this->is_phone_number_exists($phone);

        if ($email_exists) {
            $this->errmsg['post_email'] = esc_html__('Email is already in use.', 'wpcf');
            $response['error_email'] = 'Email is already in use.';
        }
        if ($phone_exists) {
            $this->errmsg['post_phone'] = esc_html__('Phone number is already in use.', 'wpcf');
            $response['error_phone'] = 'Phone number is already in use.';
        }
        if(isset($_POST['post_title']) && empty($_POST['post_title'])) { 
            $this->errmsg['post_title'] = esc_html__('Please Enter Title.', 'wpcf');
            $errors = true;
        }
        if(isset($_POST['post_email']) && empty($_POST['post_email'])) { 
            $this->errmsg['post_email'] = esc_html__('Please Enter Email.', 'wpcf');
            $errors = true;
        }
        if(isset($_POST['post_phone']) && empty($_POST['post_phone'])) { 
            $this->errmsg['post_phone'] = esc_html__('Please Enter Contact.', 'wpcf');
            $errors = true;
        }
        if(isset($_POST['post_image']) && empty($_POST['post_image'])) { 
            $this->errmsg['post_image'] = esc_html__('Please Choose Image.', 'wpcf');
            $errors = true;
        }

        if ($errors != true && $email_exists != true && $phone_exists != true) {

            if (isset($_POST['post_title'])) {
                $post_title = sanitize_text_field($_POST['post_title']);
                $post_email = sanitize_text_field($_POST['post_email']);
                $post_phone = sanitize_text_field($_POST['post_phone']);

                $post_data = array(
                    'post_title'   => $post_title,
                    'post_content' => '',
                    'post_status'  => 'publish',
                    'post_type'    => 'wpcf', // Set custom post type
                );
                $post_id = wp_insert_post($post_data);

                if (isset($_POST['post_image'])) {
                    $image_url = $_POST['post_image'];
                    $media_id = media_sideload_image($image_url, $post_id, '', 'id');
        
                    if (!is_wp_error($media_id)) {
                        set_post_thumbnail($post_id, $media_id);
                    } else {
                        $response['error'] = 'Error attaching the image to the post.';
                    }
                }

                // if (!empty($_FILES['post_image'])) {
                //     $uploaded_image = $this->wpcf_handle_image_upload($_FILES['post_image']);
            
                //     if (is_wp_error($uploaded_image)) {
                //         $response['error'] = 'Image upload error: ' . $uploaded_image->get_error_message();
                //     } else {
                //         $response['success'] = 'Image uploaded successfully.';
                //     }
                // }

                if ($post_id) {
                    update_post_meta($post_id, 'post_email', $post_email);
                    update_post_meta($post_id, 'post_phone', $post_phone);

                    if (isset($uploaded_image) && $uploaded_image) {
                        set_post_thumbnail($post_id, $uploaded_image);
                    }
                    $response['success'] = 'Your Data Submitted Successfully.';
                } else {
                    $response['error'] = 'Error Submitting Data.';
                }
            }
        }
        wp_send_json($response);
    }
    
    /**
     * Handle image upload
     *
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    private function wpcf_handle_image_upload($file) {
        $upload_overrides = array('test_form' => false);
        $uploaded_file = wp_handle_upload($file, $upload_overrides);
    
        if ($uploaded_file && !isset($uploaded_file['error'])) {
            $file_path = $uploaded_file['file'];
            $file_type = wp_check_filetype($file_path, null);
    
            $attachment = array(
                'post_mime_type' => $file_type['type'],
                'post_title'     => sanitize_file_name(pathinfo($file_path, PATHINFO_FILENAME)),
                'post_content'   => '',
                'post_status'    => 'inherit'
            );
    
            $attachment_id = wp_insert_attachment($attachment, $file_path);
    
            if (!is_wp_error($attachment_id)) {
                require_once(ABSPATH . 'wp-admin/includes/image.php');
                $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
                wp_update_attachment_metadata($attachment_id, $attachment_data);
    
                return $attachment_id;
            }
        }
        return new WP_Error('upload_error', 'Error uploading image');
    }
    
    /**
     * Check if phone number already exists
     *
     * @param string $phone Phone number to check
     * @return bool
     */
    private function is_phone_number_exists($phone) {
        $args = array(
            'post_type'      => 'wpcf',
            'meta_query'     => array(
                'relation' => 'OR',
                array(
                    'key'   => 'post_phone',
                    'value' => $phone,
                ),
            ),
        );

        $query = new WP_Query($args);
        return $query->have_posts();
    }

    /**
     * Check if email already exists
     *
     * @param string $email Phone number to check
     * @return bool
     */
    private function is_email_exists($email) {
        $args = array(
            'post_type'      => 'wpcf',
            'meta_query'     => array(
                'relation' => 'OR',
                array(
                    'key'   => 'post_email',
                    'value' => $email,
                ),
            ),
        );

        $query = new WP_Query($args);
        return $query->have_posts();
    }
}
$wpcf_shortcode = new WPCF_Shortcode();
