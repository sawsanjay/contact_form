<?php
// Exit if accessed directly
if (!defined('ABSPATH')) exit;

class WPCF_Custom_Post_Type {

    public function __construct() {
        add_action('init', array($this, 'register_custom_post_type'));
        add_filter('manage_wpcf_posts_columns', array($this, 'add_custom_columns'));
        add_action('manage_wpcf_posts_custom_column', array($this, 'custom_columns_content'), 10, 2);
        add_action('admin_menu', array($this, 'wpcf_settings_submenu'));

        // Add action to hook into the add_meta_boxes action
        add_action('add_meta_boxes', array($this, 'wpcf_add_custom_meta_boxes'));
        add_action('save_post', array($this, 'wpcf_save_custom_meta_data'));
    }

    /**
     * Register Custom Post Type
     *
     * Runs when the init hook fires and registers a new custom post type.
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function register_custom_post_type() {
        $labels = array(
            'name'               => esc_html__('Contact Users', 'wpcf'),
            'singular_name'      => esc_html__('Contact User', 'wpcf'),
            'menu_name'          => esc_html__('Contact Users', 'wpcf'),
            'add_new'            => esc_html__('Add New', 'wpcf'),
            'add_new_item'       => esc_html__('Add New Contact User', 'wpcf'),
            'edit_item'          => esc_html__('Edit Contact User', 'wpcf'),
            'new_item'           => esc_html__('New Contact User', 'wpcf'),
            'view_item'          => esc_html__('View Contact User', 'wpcf'),
            'search_items'       => esc_html__('Search Contact Users', 'wpcf'),
            'not_found'          => esc_html__('No Contact Users found', 'wpcf'),
            'not_found_in_trash' => esc_html__('No Contact Users found in Trash', 'wpcf'),
            'parent_item_colon'  => '',
            'menu_icon'          => 'dashicons-admin-post', // You can change this to your desired icon
        );

        $args = array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'wpcf'),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        );

        register_post_type('wpcf', $args);
    }

     /**
     * Add columns in wplist table
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function add_custom_columns($columns) {
        $new_columns = array();

        foreach ($columns as $key => $value) {
            $new_columns[$key] = $value;

            if ($key === 'title') {
                $new_columns['featured_image'] = 'Featured Image';
                $new_columns['post_email'] = 'Email';
                $new_columns['post_phone'] = 'Phone Number';
            }
        }

        return $new_columns;
    }
    
    /**
     * Add columns data
     *
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function custom_columns_content($column_name, $post_ID) {
        if ($column_name == 'featured_image') {
            echo get_the_post_thumbnail($post_ID, array(50, 50));
        }
        if ($column_name == 'post_email') {
            $post_email = get_post_meta($post_ID, 'post_email', true);
            echo esc_html($post_email);
        }
        if ($column_name == 'post_phone') {
            $post_phone = get_post_meta($post_ID, 'post_phone', true);
            echo esc_html($post_phone);
        }
        
    }
    
     /**
     * Add new menu for shortcode setting page
     *
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_settings_submenu() {
        add_submenu_page(
            'edit.php?post_type=wpcf', // Parent menu slug
            esc_html__('Settings', 'wpcf'), // Page title
            esc_html__('Settings', 'wpcf'), // Menu title
            'manage_options', // Capability
            'wpcf-settings', // Menu slug
            array($this, 'wpcf_settings_page') // Callback function to display the settings page
        );
    }

     /**
     * Create setting page content
     *
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_settings_page() {
        echo '<div class="wrap"><h2>Settings Page</h2>';
        echo '<p>This is your shortcode <code>[wpcf_form]</code>. You can use this shortcode to display your contact form.</p>';
        echo '</div>';
    }

     /**
     * Create custom meta box
     *
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_add_custom_meta_boxes() {
        add_meta_box(
            'wpcf_contact_details_meta_box',
            esc_html__('Contact Details', 'wpcf'),
            array($this, 'wpcf_render_contact_details_meta_box'),
            'wpcf',
            'normal',
            'default'
        );
    }

     /**
     * Display custom meta box
     *
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_render_contact_details_meta_box($post) {
        // Retrieve existing values for post_email and post_phone
        $email_value = get_post_meta($post->ID, 'post_email', true);
        $phone_value = get_post_meta($post->ID, 'post_phone', true);

        // Display fields within the Contact Details meta box
        echo '<label for="post_email">' . esc_html__('Email:', 'wpcf') . '</label>';
        echo '<input type="text" id="post_email" name="post_email" value="' . esc_attr($email_value) . '" size="25" /><br>';

        echo '<label for="post_phone">' . esc_html__('Phone:', 'wpcf') . '</label>';
        echo '<input type="text" id="post_phone" name="post_phone" value="' . esc_attr($phone_value) . '" size="25" /><br>';

        // Add nonce field for security
        wp_nonce_field('wpcf_save_contact_details_meta_box', 'wpcf_contact_details_meta_box_nonce');
    }

     /**
     * Save custom meta box
     *
     * 
     * @package WP CONTACT FORM
     * @since 1.0.0
     */
    public function wpcf_save_custom_meta_data($post_id) {
        // Check if the nonce is set and valid
        if (isset($_POST['wpcf_contact_details_meta_box_nonce']) && wp_verify_nonce($_POST['wpcf_contact_details_meta_box_nonce'], 'wpcf_save_contact_details_meta_box')) {
            // Save the meta data
            $email_key = 'post_email';
            $phone_key = 'post_phone';

            if (isset($_POST['post_email'])) {
                $email_value = sanitize_text_field($_POST['post_email']);
                update_post_meta($post_id, $email_key, $email_value);
            }

            if (isset($_POST['post_phone'])) {
                $phone_value = sanitize_text_field($_POST['post_phone']);
                update_post_meta($post_id, $phone_key, $phone_value);
            }
        }
    }
}
$custom_post_type = new WPCF_Custom_Post_Type();
