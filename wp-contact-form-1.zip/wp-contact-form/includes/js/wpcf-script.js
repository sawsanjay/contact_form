jQuery(document).ready(function($) {
    $('#submit-btn').click(function(e) {
        e.preventDefault(); 
        var postTitle = $('#post_title').val();
        var postEmail = $('#post_email').val();
        var postPhone = $('#post_phone').val();
        var postImage = $('#post_image').val();
        
        var messageDiv = $('#message');
        var emailmessageDiv = $('#email_message');
        var phonemessageDiv = $('#phone_message');
        messageDiv.html('');
        emailmessageDiv.html('');
        phonemessageDiv.html('');
        var fileInput = $('#post_image')[0];
        var formData = new FormData();
        formData.append('action', 'wpcf_handle_form_submission');
        formData.append('post_title', postTitle);
        formData.append('post_email', postEmail);
        formData.append('post_phone', postPhone);
        formData.append('post_image', postImage);

        // if (fileInput.files.length > 0) {
        //     formData.append('post_image', fileInput.files[0]);
        // }

        $('.error').remove();
        var error = false;
        if (!postTitle) {
            $('#post_title').after('<div class="error">Please Enter Your Name.</div>');
            error = true;
        }
        if (!postEmail) {
            $('#post_email').after('<div class="error">Please Enter Your Email.</div>');
            error = true;
        } else if (!isValidEmail(postEmail)) {
            $('#post_email').after('<div class="error">Please Enter a Valid Email.</div>');
            error = true;
        }
        function isValidEmail(email) {
            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailPattern.test(email);
        }
        if (!postPhone) {
            $('#post_phone').after('<div class="error">Please Enter Your Phone Number.</div>');
            error = true;
        } else if (!isValidPhone(postPhone)) {
            $('#post_phone').after('<div class="error">Please Enter a Valid Phone Number (10-15 digits).</div>');
            error = true;
        }
        function isValidPhone(phone) {
            var phonePattern = /^[0-9+\-]{10,15}$/;
            return phonePattern.test(phone);
        }
        // Validate the image URL
        if (!postImage) {
            $('#post_image').after('<div class="error">Please Choose Your Image.</div>');
            error = true;
        } else if (!isValidImageUrl(postImage)) {
            $('#post_image').after('<div class="error">Please Choose a Valid Image Formats.</div>');
            error = true;
        }
        function isValidImageUrl(url) {
            var imageUrlPattern = /\.(jpeg|jpg|png)$/i;
            return imageUrlPattern.test(url);
        }
        // if (fileInput.files.length === 0) {
        //     $('#post_image').after('<div class="error">Please Choose Your Image.</div>');
        //     error = true;
        // } else {
        //     var imageFile = fileInput.files[0];
        //     var allowedTypes = ['image/jpeg', 'image/png'];
        //     var maxSizeInBytes = 2 * 1024 * 1024; // 2 MB

        //     if (allowedTypes.indexOf(imageFile.type) === -1) {
        //         $('#post_image').after('<div class="error">Please choose a valid image type (JPEG or PNG).</div>');
        //         error = true;
        //     } else if (imageFile.size > maxSizeInBytes) {
        //         $('#post_image').after('<div class="error">Image size must be under 2MB.</div>');
        //         error = true;
        //     }
        // }
        if(error == false) {
            $('#submit-btn').val('Submitting...').attr('disabled', true);
            $.ajax({
                type: 'POST',
                url: wpcf_vars.ajaxurl,
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if(response.success){
                        messageDiv.html('<strong style="color: green;">' + response.success + '</strong>');
                        $('#post_title, #post_email, #post_phone, #post_image').val('');
                        $('#selected_image_preview').attr('src', 'http://sanjay.wpweb.co.in/wordpress2/wp-content/uploads/2023/12/images.png');
                    }
                    if(response.error_email)
                    {
                        emailmessageDiv.html('<strong style="color: red;">' + response.error_email + '</strong>');
                    }
                    if(response.error_phone)
                    {
                        phonemessageDiv.html('<strong style="color: red;">' + response.error_phone + '</strong>');
                    }
                    $('#submit-btn').val('SUBMIT').attr('disabled', false);
                },  
                error: function(error) {
                    messageDiv.html('<strong style="color: red;">' + error.responseText + '</strong>');
                }
            });
        }
    });
});
