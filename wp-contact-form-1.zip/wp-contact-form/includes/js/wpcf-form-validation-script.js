jQuery(document).ready(function ($) {
    // Validate the form
    $.validator.addMethod('phoneValidation', function (value, element) {
        return this.optional(element) || /^[0-9+\-]+$/.test(value);
    }, 'Only digits, plus sign (+), and hyphen (-) are allowed.');

    $('#wpfp-form').validate({
        
        rules: {
            post_title: {
                required: true,
                maxlength: 20 // Adjust the max length if needed
            },
            post_email: {
                required: true,
                email: true
            },
            post_phone: {
                required: true,
                phoneValidation: true,
                minlength: 10,
                maxlength: 15 // Adjust the min and max length if needed
            },
            post_image: {
                required: true,
                extension: 'jpeg|png',
                filesize: 2 * 1024 * 1024 // 2 MB limit
            }
        },
        messages: {
            post_phone: {
                phoneValidation: 'Only digits, plus sign (+), and hyphen (-) are allowed.',
                minlength: 'Phone number must be at least 10 characters.',
                maxlength: 'Phone number must not exceed 15 characters.'
            },
            post_image: {
                extension: 'Only JPEG and PNG files are allowed.',
                filesize: 'File size must be less than 2 MB.'
            }
        },
        submitHandler: function (form) {
            
            // Handle form submission via AJAX or submit normally
            form.submit();
        }
    });
});
